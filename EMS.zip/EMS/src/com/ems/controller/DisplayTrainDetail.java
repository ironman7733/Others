package com.ems.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.bean.TrainBean;

/**
 * Servlet implementation class DisplayTrainDetail
 */
@WebServlet("/DisplayTrainDetail")
public class DisplayTrainDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayTrainDetail() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		List<TrainBean> list = (List<TrainBean>)request.getAttribute("list");
		
		out.println("<table border = \"1\" ");
		for(TrainBean bean : list)
		{
			//out.println("<tr><td>"+bean.getTrainId()+"</td>");
			out.println("<tr><td><a href=\"ShowTrainInfo?tid="+bean.getTrainId()+"\">"+bean.getTrainId()+"\"</td>");
			out.println("<td>"+bean.getTrainName()+"</td>");
			out.println("<td>"+bean.getTrainDest()+"</td>");
			out.println("<td>"+bean.getTrainSeats()+"</td>");
			out.println("<td>"+bean.getTrainFare()+"</td>");
			out.println("<td>"+bean.getTrainDept()+"</td>");
			out.println("</tr>");
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
