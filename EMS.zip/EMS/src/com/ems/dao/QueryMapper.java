package com.ems.dao;

public interface QueryMapper 
{
	public static final String SELECT_QUERY = "select TrainId,TrainName,Destination,DepartDate,Seats,fare from TrainDetails";
	public static final String SELECT_BY_ID = "select TrainId,TrainName,Destination from TrainDetails where  TrainId = ?";
	public static final String UPDATE_QRY = "update TrainDetails set seats = seats - ? where TrainId = ?";
}
