package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements IEmployeeDao {

	private Map<Integer,EmployeeBean> map=new HashMap<Integer,EmployeeBean>();
	private EmployeeBean bean=new EmployeeBean();
	private static Logger log = Logger.getLogger(EmployeeDaoImpl.class);
	public EmployeeDaoImpl(){
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		
		int id=0;
		log.debug("Add employee called");
		Connection con=DBConnection.getConnection();
		log.debug("Connection successful");
		String query=QueryMapper.INSERT_QUERY;
		
		try {
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setString(1, bean.getEmployeeName());
			pstmt.setDouble(2, bean.getEmployeeSalary());
			int count=pstmt.executeUpdate();
			if(count<=0){
				log.info("Insertion failed");
				throw new EmployeeException("Insert failed. ");
			}
			query=QueryMapper.SELECT_ID_QUERY;
			pstmt=con.prepareStatement(query);
			ResultSet res=pstmt.executeQuery();
			if(res.next())
			{
				id=res.getInt(1);
			}
			else
			{
				log.info("Unable to read.");
				throw new EmployeeException("Unable to read from the sequence");
			}	log.info("Employee added.");
			con.close();
		} catch (SQLException e) {
			log.error(e);
			throw new EmployeeException(e.getMessage());
		}
		
		return (id);
	}

	@Override
	public EmployeeBean findEmployeeById(int id) throws EmployeeException {
		Connection con= null;
		log.debug("Finding employee by ID.");
		try {
			con=DBConnection.getConnection();
			log.debug("Connection established");
			String query =QueryMapper.SELECT_BY_ID;
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, id);
			ResultSet res = pstmt.executeQuery();
			if(res.next())
			{
				System.out.println(res.getInt("empid")+" "+res.getString("empname")+" "+res.getInt("empsalary"));
			}
			else
			{
				log.error("Id couldn't be found.");
				System.out.println("ID not found!");
			}log.info("Employee retrieved");
		} catch (SQLException e) {
			log.error(e);
			throw new EmployeeException("ID NOT AVAILABLE "+e.getMessage());
		}
		return bean;
		
		
	}

	@Override
	public EmployeeBean deleteEmployeeById(int id) throws EmployeeException {
		Connection con = null;
		log.debug("Deleting Employees by ID");
		
		try {
			con=DBConnection.getConnection();
			log.debug("Connection established");
			
//			Scanner scr= new Scanner(System.in);
			
String query=QueryMapper.DELETE_BY_ID;
PreparedStatement pstmt=con.prepareStatement(query);
pstmt.setInt(1, id);
int count=pstmt.executeUpdate();
if(count==0){
	log.error("Id couldn't be found.");
			System.out.println("Empid not found!");
}
else{
			System.out.println("Deletion successful! Record(s) deleted: "+count);
			log.info("Employee deleted");
}
		} catch (SQLException e) {
			log.error(e);
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public List<EmployeeBean> showAllEmployee() throws EmployeeException {
		List<EmployeeBean> myList;
		try {log.debug("Showing All Employees.");
			myList = new ArrayList<EmployeeBean>();
			Connection con=DBConnection.getConnection();
			log.debug("Connection established");
			String query=QueryMapper.SELECT_ALL_EMP_QUERY;
			PreparedStatement pstmt=con.prepareStatement(query);
			ResultSet res=pstmt.executeQuery();
			while(res.next())
			{
				EmployeeBean bean= new EmployeeBean();
				bean.setEmployeeId(res.getInt("empid"));
				bean.setEmployeeName(res.getString("empname"));
				bean.setEmployeeSalary(res.getDouble("empsalary"));
				myList.add(bean);
			}log.info("Details retrieved");
			con.close();
		} catch (SQLException e) {
			log.error(e);
			throw new EmployeeException("Employ details couldn't be fetched."+e.getMessage());
		}
		return myList;
	}
		
}
