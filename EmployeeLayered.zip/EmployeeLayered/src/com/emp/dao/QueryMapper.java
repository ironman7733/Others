package com.emp.dao;

public class QueryMapper {
	
public static final String INSERT_QUERY="insert into emp_tbl(empid,empname,empsalary) values(id_seq.nextval,?,?)";
public static final String SELECT_ID_QUERY="select id_seq.currval from dual";
public static final String SELECT_ALL_EMP_QUERY="select empid,empname,empsalary from emp_tbl";
public static final String SELECT_BY_ID="select empid,empname,empsalary from emp_tbl where empid=?";
public static final String DELETE_BY_ID="delete from emp_tbl where empid=?";
}
