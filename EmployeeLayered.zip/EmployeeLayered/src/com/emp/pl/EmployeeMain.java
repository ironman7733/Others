package com.emp.pl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeServiceImpl;
import com.emp.service.IEmployeeService;

public class EmployeeMain {
	public static void main(String[] args) {
		int empid;
		Scanner sc = new Scanner(System.in);
		IEmployeeService employeeService = new EmployeeServiceImpl();

		while (true) {
			System.out.println("Employee Management App");
			System.out.println("------------------------");
			System.out.println("1. Add an Employee");
			System.out.println("2. Search Employee By ID");
			System.out.println("3. Delete Employee By ID");
			System.out.println("4. Show All Employees");
			System.out.println("5. Exit");

			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				/*
				 * System.out.println("Enter Emp Id "); int id=sc.nextInt(); sc.nextLine();
				 */
				sc.nextLine();
				System.out.println("Enter Emp Name ");
				String name = sc.nextLine();
				System.out.println("Enter Salary ");
				double salary = sc.nextDouble();

				EmployeeBean emp = new EmployeeBean();

				emp.setEmployeeName(name);
				emp.setEmployeeSalary(salary);
				System.out.println(emp.toString());

				try {
					int id = employeeService.addEmployee(emp);
					if (id > 0) {
						System.out.println("Employee Added Successfully");
						System.out.println("Id: " + id);
					} else
						System.out.println("Employee Fail to Add");
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
				break;

			case 2:
				System.out.println("Enter Employee ID to find");
				empid = sc.nextInt();
				try {
					emp = employeeService.findEmployeeById(empid);
					System.out.println(emp.toString());
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
				break;

			case 3:
				System.out.println("Enter Employee ID to find");
				empid = sc.nextInt();
				try {
					emp = employeeService.deleteEmployeeById(empid);
					System.out.println("Employee Deleted" + emp.toString());
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}

				break;

			case 4:
				try {
					List<EmployeeBean> mylist = employeeService.showAllEmployee();
					for (EmployeeBean bean : mylist) {
						System.out.println(
								bean.getEmployeeId() + " " + bean.getEmployeeName() + " " + bean.getEmployeeSalary());
					}
				} catch (EmployeeException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			case 5: {
				System.exit(0);
			}

				Default: {
					System.out.println("Invalid Choice");
				}

				System.out.println("************************************");
			}

		}
	}
}
