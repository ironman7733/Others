package jdbcdemos;

import java.sql.*;
import javax.sql.*;

public class TestConnection 
{

	public static void main(String[] args) 
	{

		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			Connection conn = DriverManager.getConnection(url, "system", "orcl10g");
			Statement stmt = conn.createStatement();
			System.out.println("Connection Established");
			ResultSet rs = stmt.executeQuery("SELECT * FROM STUDENT_TABLE"); 
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  

			}
			stmt.close();
			conn.close();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}

	}
}
