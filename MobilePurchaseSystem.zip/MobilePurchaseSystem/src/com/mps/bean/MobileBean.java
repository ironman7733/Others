package com.mps.bean;

public class MobileBean 
{

	private int MobileId;
	private String MobileName;
	private double Price;
	private String quantity;
	public int getMobileId() 
	{
		return MobileId;
	}
	public void setMobileId(int mobileId) 
	{
		MobileId = mobileId;
	}
	public String getMobileName() 
	{
		return MobileName;
	}
	public void setMobileName(String mobileName) 
	{
		MobileName = mobileName;
	}
	public double getPrice() 
	{
		return Price;
	}
	public void setPrice(double price) 
	{
		Price = price;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) 
	{
		this.quantity = quantity;
	}
	public MobileBean(int mobileId, String mobileName, double price, String quantity) 
	{
		super();
		MobileId = mobileId;
		MobileName = mobileName;
		Price = price;
		this.quantity = quantity;
	}
	public MobileBean() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
}
