package com.mps.bean;

public class PurchaseBean 
{

	private int PurchaseId;
	private String CustomerName;
	private String MailId;
	private String PurchaseDate;
	public int getPurchaseId() 
	{
		return PurchaseId;
	}
	public void setPurchaseId(int purchaseId) 
	{
		PurchaseId = purchaseId;
	}
	public String getCustomerName() 
	{
		return CustomerName;
	}
	public void setCustomerName(String customerName) 
	{
		CustomerName = customerName;
	}
	public String getMailId() 
	{
		return MailId;
	}
	public void setMailId(String mailId) 
	{
		MailId = mailId;
	}
	public String getPurchaseDate() 
	{
		return PurchaseDate;
	}
	public void setPurchaseDate(String date) 
	{
		PurchaseDate = date;
	}
	public PurchaseBean(int purchaseId, String customerName, String mailId, String purchaseDate) 
	{
		super();
		PurchaseId = purchaseId;
		CustomerName = customerName;
		MailId = mailId;
		PurchaseDate = purchaseDate;
	}
	public PurchaseBean() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
