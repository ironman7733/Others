package com.mps.dao;

import com.mps.bean.PurchaseBean;
import com.mps.exception.PurchaseException;

public interface IPurchaseDao {
	public int addCustomer(PurchaseBean purchase) throws PurchaseException;

}
