package com.mps.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mps.bean.PurchaseBean;
import com.mps.exception.PurchaseException;
import com.mps.util.DBConnection;

public class PurchaseDaoImpl implements IPurchaseDao {

	private PurchaseBean purchase = new PurchaseBean();
	@Override
	public int addCustomer(PurchaseBean purchase) throws PurchaseException {
		int id = 0;
		Connection con = DBConnection.getConnection();
		con = null;
		String query = QueryMapper.INSERT_QUERY;

		try {
			
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, purchase.getCustomerName());
			pstmt.setString(2, purchase.getMailId());
			pstmt.setString(3, purchase.getPurchaseDate());
			int count = pstmt.executeUpdate();
			if (count <= 0) {

				throw new PurchaseException("Insert failed. ");
			}
			query = QueryMapper.INSERT_QUERY;
			pstmt = con.prepareStatement(query);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				id = res.getInt(1);
			} else {
				throw new PurchaseException("Unable to read from the sequence");
			}
			con.close();
		} catch (SQLException e) {
			throw new PurchaseException(e.getMessage());
		}

		return (id);
	}

}
