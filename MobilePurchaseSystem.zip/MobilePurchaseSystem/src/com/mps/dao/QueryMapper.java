package com.mps.dao;

public class QueryMapper {
	public static final String INSERT_QUERY="insert into purchasedetails(purchaseid,customername,mailid,phonenumber,purchasedate) values(id_seq.nextval,?,?,?,?)";
}
