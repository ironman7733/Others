package com.mps.exception;

public class PurchaseException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7675862249848687767L;
	public PurchaseException(String message)
	{
		super(message);
	
	}
}