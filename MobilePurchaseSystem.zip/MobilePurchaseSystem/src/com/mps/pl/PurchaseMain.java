package com.mps.pl;

import java.sql.Date;
import java.util.Scanner;

import com.mps.bean.PurchaseBean;
import com.mps.exception.PurchaseException;
import com.mps.service.IPurchaseService;
import com.mps.service.PurchaseServiceImpl;

public class PurchaseMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		IPurchaseService purchaseService=new PurchaseServiceImpl();
		//sc.nextLine();
		System.out.println("Enter customer Name ");
		Scanner sc=new Scanner(System.in);
		String name=sc.nextLine();
		System.out.println("Enter mailid ");
		String mailid=sc.next();
		System.out.println("Enter purchasedate ");
		String date=sc.next();
		
		PurchaseBean purchase = new PurchaseBean();
	

		
		purchase.setCustomerName(name);
		purchase.setMailId(mailid);
		purchase.setPurchaseDate(date);
		
		System.out.println(purchase.toString());
		
		try {
			int id=purchaseService.addCustomer(purchase);
			if(id>0){
				System.out.println("Employee Added Successfully");
			System.out.println("Id: "+id);
		}
			else
				System.out.println("Employee Fail to Add");
			} catch (PurchaseException e) {
				System.out.println(e.getMessage());
				}
	}

}
