package com.mps.service;


import com.mps.bean.PurchaseBean;
import com.mps.exception.PurchaseException;

public interface IPurchaseService {

	public int addCustomer(PurchaseBean purchase) throws PurchaseException;	
}
