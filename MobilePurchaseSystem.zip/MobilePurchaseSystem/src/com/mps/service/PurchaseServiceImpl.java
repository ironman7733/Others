package com.mps.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.mps.bean.PurchaseBean;
import com.mps.dao.IPurchaseDao;
import com.mps.dao.PurchaseDaoImpl;
import com.mps.exception.PurchaseException;

public class PurchaseServiceImpl implements IPurchaseService {
	private IPurchaseDao purchaseDao = new PurchaseDaoImpl();

	@Override
	public int addCustomer(PurchaseBean purchase) throws PurchaseException {

		int id = 0;
		if (validateCustomerName(purchase.getCustomerName())) {
			id = purchaseDao.addCustomer(purchase);
		} else {
			throw new PurchaseException("Customer  NAME SHOULD HAVE A MINIMUM OF 4 CHARACTERS");

		}
		return id;
	}

	public boolean validateCustomerName(String name) {
		boolean flag = false;
		Pattern pattern = Pattern.compile("[a-zA-Z/s]{4,}");
		Matcher matcher = pattern.matcher(name);
		if (matcher.matches()) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;
	}

}
