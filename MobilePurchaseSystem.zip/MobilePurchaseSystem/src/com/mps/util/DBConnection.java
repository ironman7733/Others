package com.mps.util;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.mps.exception.PurchaseException;

public class DBConnection {

	public static Connection getConnection() throws PurchaseException {
		
			try {
				Connection con=null;
				Properties prop = new Properties();
				FileReader fr = new FileReader("resources/jdbc.properties");
				prop.load(fr);
				String driver = prop.getProperty("driver");
				String url = prop.getProperty("dburl");
				String user = prop.getProperty("dbuser");
				String pass = prop.getProperty("dbpass");
				Class.forName(driver);
		    System.out.println("Driver loaded successfully!");
				con = DriverManager.getConnection(url, user, pass);
			System.out.println("Connection established!");
				return con;
			} catch (FileNotFoundException e) {
				throw new PurchaseException("JDBC PROPERTIES FILE NOT FOUND"+e.getMessage());
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				throw new PurchaseException("UNABLE TO READ JDBC PROPERTIES FILE"+e.getMessage());
			} catch (SQLException e) {
				throw new PurchaseException("CONNECTION NOT ESTABLISHED"+e.getMessage());
			}
		
		
		return null;

	}

}
