package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements IEmployeeDao {

	private EmployeeBean bean = new EmployeeBean();

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {

		int id = 0;
		Connection con = DBConnection.getConnection();
		String query = QueryMapper.INSERT_QUERY;
		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, bean.getEmployeeName());
			pstmt.setDouble(2, bean.getEmployeeSalary());
			int count = pstmt.executeUpdate();
			if (count <= 0) {

				throw new EmployeeException("Insert failed. ");
			}
			query = QueryMapper.SELECT_ID_QUERY;
			pstmt = con.prepareStatement(query);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				id = res.getInt(1);
			} else {

				throw new EmployeeException("Unable to read from the sequence");
			}
			con.close();
		} catch (SQLException e) {

			throw new EmployeeException(e.getMessage());
		}

		return (id);
	}

	@Override
	public EmployeeBean deleteEmployeeById(int id) throws EmployeeException {
		Connection con = null;

		try {
			con = DBConnection.getConnection();

			String query = QueryMapper.DELETE_BY_ID;
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, id);
			int count = pstmt.executeUpdate();
			if (count == 0) {

				System.out.println("Empid not found!");
			} else {
				System.out.println("Deletion successful! Record(s) deleted: " + count);

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public EmployeeBean findEmployeeById(int id) throws EmployeeException {
		Connection con = null;

		try {
			con = DBConnection.getConnection();

			String query = QueryMapper.SELECT_BY_ID;
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, id);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				System.out
						.println(res.getInt("empid") + " " + res.getString("empname") + " " + res.getInt("empsalary"));
			} else {

				System.out.println("ID not found!");
			}
		} catch (SQLException e) {

			throw new EmployeeException("ID NOT AVAILABLE " + e.getMessage());
		}
		return bean;
	}

	@Override
	public List<EmployeeBean> showAllEmployee() throws EmployeeException 
	{
		
			List<EmployeeBean> myList;
			try
			{
				myList = new ArrayList<EmployeeBean>();
				Connection con=DBConnection.getConnection();
				
				String query=QueryMapper.SELECT_ALL_EMP_QUERY;
				PreparedStatement pstmt=con.prepareStatement(query);
				ResultSet res=pstmt.executeQuery();
				while(res.next())
				{
					EmployeeBean bean= new EmployeeBean();
					bean.setEmployeeId(res.getInt("empid"));
					bean.setEmployeeName(res.getString("empname"));
					bean.setEmployeeSalary(res.getDouble("empsalary"));
					myList.add(bean);
				}
				con.close();
			} 
			catch(SQLException e) 
			{
			
				throw new EmployeeException("Employ details couldn't be fetched."+e.getMessage());
			}
			return myList;
	}
}


