package com.emp.dao;

public class QueryMapper {

	public static final String INSERT_QUERY="insert into emp_tab1(empid,empname,empsalary) values(eid_seq.nextval,?,?)";
	public static final String SELECT_ID_QUERY="select eid_seq.currval from dual";
	public static final String SELECT_ALL_EMP_QUERY="select empid,empname,empsalary from emp_tab1";
	public static final String DELETE_BY_ID="delete from emp_tab1 where empid=?";
	public static final String SELECT_BY_ID="select empid,empname,empsalary from emp_tab1 where empid=?";
}
