package com.emp.exception;

public class EmployeeException extends Exception{

	private static final long serialVersionUID = 8808419149400977939L;

	public EmployeeException(String message)
	{
		super(message);
	}
}
