package com.emp.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.dao.IEmployeeDao;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService{

	private IEmployeeDao employeeDao = new EmployeeDaoImpl();
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		
		int id=0;		
		if(validateEmployeeName(bean.getEmployeeName()))
		{
			id=employeeDao.addEmployee(bean);
		}
		else
		{
			throw new EmployeeException("EMPLOYEE  NAME SHOULD HAVE A MINIMUM OF 4 CHARACTERS");
			
		}
		return id;
	}
	
	public boolean validateEmployeeId(int id)
	{
		boolean flag=false;
		Pattern pattern=Pattern.compile("[0-9]{4}");
		Matcher matcher=pattern.matcher(String.valueOf(id));
		if(matcher.matches())
		{	
			flag=true;
		}
		else
		{
			flag=false;
		}
			return flag;
	}
	public boolean validateEmployeeName(String name)
	{
		boolean flag=false;
		Pattern pattern=Pattern.compile("[a-zA-Z/s]{4,}");
		Matcher matcher=pattern.matcher(name);
		if(matcher.matches())
		{	
			flag=true;
		}
		else
		{
			flag=false;
		}
		return flag;
	}

	@Override
	public EmployeeBean deleteEmployeeById(int id) throws EmployeeException {
		if(validateEmployeeId(id))
		{
			return employeeDao.deleteEmployeeById(id);
		}
		else
		{
			throw new EmployeeException("EMPLOYEE  ID SHOULD BE 4 DIGIT");
					
		}
		
	}

	@Override
	public EmployeeBean findEmployeeById(int id) throws EmployeeException {
		if(validateEmployeeId(id))
		{
			return employeeDao.findEmployeeById(id);
		}
		else
		{
			throw new EmployeeException("EMPLOYEE  ID SHOULD BE 4 DIGIT");
					
		}
	}

	@Override
	public List<EmployeeBean> showAllEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.showAllEmployee();
	}
}


